import { useMemo, useState } from "react";
import SourceList from "./components/SourceList";
import PlanCard from "./components/PlanCard";
import ChecklistTable from "./components/ChecklistTable";
import SponsorBadges from "./components/SponsorBadges";
import { useInterval } from "./utils/useInterval";
import { toCSV, downloadCSV } from "./utils/csv";
import { mockRunResponse } from "./mock/mockRunResponse";

const BACKEND = import.meta.env.VITE_BACKEND_URL;

const TOPICS = [
  { value: "cyber outage", label: "Cyber Outage" },
  { value: "earthquake", label: "Earthquake / Disaster" },
  { value: "market crash", label: "Market Shock" },
  { value: "infrastructure outage", label: "Infrastructure Outage" },
];

const INTERVALS = [
  { label: "Off", ms: null },
  { label: "15s", ms: 15000 },
  { label: "30s", ms: 30000 },
  { label: "60s", ms: 60000 },
];

export default function App() {
  const [topic, setTopic] = useState(TOPICS[0].value);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [autoMs, setAutoMs] = useState(null);
  const [lastRun, setLastRun] = useState(null);

  // Your mock structure: plan.recommended_actions
  const actions = useMemo(() => data?.plan?.recommended_actions ?? [], [data]);

  async function runAgent() {
    setLoading(true);
    setErrorMsg("");

    try {
      // If backend env missing, use mock directly
      if (!BACKEND) throw new Error("VITE_BACKEND_URL not set");

      const res = await fetch(`${BACKEND}/run`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic }),
      });

      if (!res.ok) throw new Error(`Backend error: HTTP ${res.status}`);
      const json = await res.json();

      setData(json);
      setLastRun(new Date());
    } catch (e) {
      // Demo-safe fallback
      setData(mockRunResponse);
      setLastRun(new Date());
      setErrorMsg(
        "Backend not reachable (Failed to fetch). Showing mock data so the demo still works."
      );
    } finally {
      setLoading(false);
    }
  }

  function onDownloadCSV() {
    if (!actions.length) return;
    const csv = toCSV(actions);
    downloadCSV("numeric_checklist.csv", csv);
  }

  // Autonomous auto-run
  useInterval(() => {
    if (!loading && autoMs) runAgent();
  }, autoMs);

  return (
    <div style={page}>
      <header style={header}>
        <div>
          <h1 style={{ margin: 0 }}>SentinelOps</h1>
          <p style={{ margin: "6px 0 0", color: "#444" }}>
            Autonomous News → Action Agent (Crisis / Market Watcher)
          </p>

          <div style={{ marginTop: 6, fontSize: 12, color: "#666" }}>
            Last run: {lastRun ? lastRun.toLocaleString() : "—"}
          </div>

          <SponsorBadges />
        </div>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <select
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            style={select}
            disabled={loading}
          >
            {TOPICS.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>

          <button onClick={runAgent} disabled={loading} style={button}>
            {loading ? "Running..." : "Run Agent"}
          </button>

          <button
            onClick={onDownloadCSV}
            disabled={!actions.length}
            style={{ ...button, opacity: actions.length ? 1 : 0.6 }}
          >
            Download Checklist (CSV)
          </button>

          <select
            value={autoMs ?? "null"}
            onChange={(e) => setAutoMs(e.target.value === "null" ? null : Number(e.target.value))}
            style={selectSmall}
            disabled={loading}
            title="Auto-run agent"
          >
            {INTERVALS.map((i) => (
              <option key={i.label} value={i.ms ?? "null"}>
                Auto-run: {i.label}
              </option>
            ))}
          </select>
        </div>
      </header>

      {loading ? (
        <div style={info}>
          🤖 Agent analyzing signals… (Tavily news + Airbyte feeds + Neo4j graph update)
        </div>
      ) : null}

      {errorMsg ? (
        <div style={warning}>
          <strong>Note:</strong> {errorMsg}
        </div>
      ) : null}

      <main style={grid}>
        <section style={card}>
          <h2 style={h2}>Sources</h2>
          <SourceList sources={data?.sources ?? []} />
        </section>

        <section style={card}>
          <h2 style={h2}>Incident Plan</h2>
          <PlanCard plan={data?.plan} />
        </section>

        <section style={card}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <h2 style={h2}>Checklist</h2>
            <div style={{ display: "flex", gap: 10 }}>
              <span style={smallPill}>Graph: {data?.graph_status ?? "—"}</span>
              <span style={smallPill}>Event: {data?.event?.event_id ?? "—"}</span>
            </div>
          </div>

          <ChecklistTable actions={actions} />
        </section>
      </main>

      <footer style={{ marginTop: 18, color: "#666", fontSize: 12 }}>
        Demo-safe: if backend is down, mock mode still works.
      </footer>
    </div>
  );
}

const page = {
  minHeight: "100vh",
  background: "#f6f7fb",
  padding: 18,
  fontFamily: 'ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial',
};

const header = {
  display: "flex",
  justifyContent: "space-between",
  gap: 16,
  alignItems: "center",
  flexWrap: "wrap",
  padding: 14,
  border: "1px solid #e9e9e9",
  borderRadius: 14,
  background: "white",
};

const grid = {
  display: "grid",
  gridTemplateColumns: "1fr",
  gap: 14,
  marginTop: 14,
};

const card = {
  border: "1px solid #e9e9e9",
  borderRadius: 14,
  padding: 14,
  background: "white",
};

const h2 = {
  margin: "0 0 10px",
  fontSize: 16,
};

const select = {
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #ddd",
  background: "white",
};

const selectSmall = {
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #ddd",
  background: "white",
  fontSize: 13,
};

const button = {
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #ddd",
  background: "white",
  cursor: "pointer",
};

const warning = {
  marginTop: 12,
  padding: 12,
  borderRadius: 12,
  border: "1px solid #ffe3aa",
  background: "#fff7e6",
};

const info = {
  marginTop: 12,
  padding: 12,
  borderRadius: 12,
  border: "1px solid #cfe1ff",
  background: "#eef5ff",
};

const smallPill = {
  border: "1px solid #eee",
  background: "#fafafa",
  borderRadius: 999,
  padding: "4px 10px",
  fontSize: 12,
  height: "fit-content",
};
